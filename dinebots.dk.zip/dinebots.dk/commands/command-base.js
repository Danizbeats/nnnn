const {prefix} = require('../config.json')

const validatePermissions = (permissions) => {
    const validPermissions = [
        "ADMINISTRATOR",
        "CREATE_INSTANT_INVITE",
        "KICK_MEMBERS",
        "BAN_MEMBERS",
        "MANAGE_CHANNELS",
        "MANAGE_GUILD",
        "ADD_REACTIONS",
        "VIEW_AUDIT_LOG",
        "PRIORITY_SPEAKER",
        "STREAM",
        "VIEW_CHANNEL",
        "SEND_MESSAGES",
        "SEND_TTS_MESSAGES",
        "MANAGE_MESSAGES",
        "EMBED_LINKS",
        "ATTACH_FILES",
        "READ_MESSAGE_HISTORY",
        "MENTION_EVERYONE",
        "USE_EXTERNAL_EMOJIS",
        "VIEW_GUILD_INSIGHTS",
        "CONNECT",
        "SPEAK",
        "MUTE_MEMBERS",
        "DEAFEN_MEMBERs",
        "MOVE_MEMBERS",
        "USE_VAD",
        "CHANGE_NICKNAME",
        "MANAGE_NICKNAMEs",
        "MANAGE_ROLES",
        "MANAGE_WEBHOOKS",
        "MANAGE_EMOJIS",
    ]

    for(const permossion of permissions){
        if(!validPermissions.includes(permossion)) {
            throw new Error(`Unkown permission node "${permossion}"`)
        }
    }

}

module.exports = (bot, commandOptions) => {
    let {
        commands,
        expectedArgs = '',
        PermError = 'Du har ikke adgang til, at bruge denne command',
        minArgs = 0,
        maxArgs = null,
        permissiongs = [],
        requiredRoles = [],
        callback,
    } = commandOptions

    // Commands are in an array
    if(typeof commands === 'string'){
        commands = [commands]
    }


    console.log(`<<< Command "${commands[0]}" tilføjet! >>>`)
   


    // Makes sure the permission is correct 
    if(permissiongs.length) {
        if(typeof permissiongs === "string"){
            permissiongs = [permissiongs]
        }
        validatePermissions(permissiongs)
    }



    
    // Listen for the messages
    bot.on('message', message=>{
        if(message.author.bot){return;}
        if(message.channel.type === "dm"){return;}
        const {member, content, guild} = message

        for(const alias of commands){
            if (content.toLowerCase().startsWith(`${prefix}${alias.toLowerCase()}`)){
                // Run command has been ran

                // Make sure the user has the required permissions
                for (const permission of permissiongs){
                    if(!member.hasPermission(permission)){
                        message.reply(PermError)
                        return
                    }
                }

                // Make sure the user has the required roles

                for (const requiredRole of requiredRoles){
                        const role = guild.roles.cache.find(role => role.name === requiredRole)
                        
                        if(!role || !member.roles.cache.has(role.id)){
                            message.reply(`Du skal have "${requiredRole}" rollen for at bruge denne coammand`)
                            return
                        }
                        
                }


                const args = content.split(/[ ]+/);
                args.shift()

                // Make sure that we have the right amount of args
                if (args.length<minArgs || (
                    maxArgs !== null && args.length> maxArgs
                )){
                    message.reply(`Forkerte måde du bruge commanden på. Brug ${prefix}${alias} ${expectedArgs}`)
                    return
                }

                // Handle the code
                callback(message, args, args.join(' '))

                return
            }
        }
    });

}