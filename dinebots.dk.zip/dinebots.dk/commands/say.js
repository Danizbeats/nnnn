const Discord = require('discord.js');
const bot = new Discord.Client();
const cfg = require('../config.json');
const index = require('../index.js')


module.exports = {
    commands: 'say',
    expectedArgs: '<besked>',
    PermError: 'Du har ikke adgang til, at bruge denne command',
    minArgs: 1,
    callback: (message, arguments, text) => {
        // TODO:
      message.channel.bulkDelete('1')
      message.channel.send(text)
      


      // const embed = new Discord.MessageEmbed()
      //   // .setTitle(message.guild.name)
      //   .setAuthor("🎉Giveaway🎉", message.guild.iconURL())
      //   .setColor(cfg.blue_light)
      //   .setDescription(`Giveaway. Reager med 🎁. For at være med. Den bliver trukket i morgen kl. 17:00\nDu kan vinde:**\n\n- mb-bitcoin\n\n20%rabat på(valg frit)\n\n50 kr.(mobilepay)**`)
      //   .setFooter(message.guild.name, message.guild.iconURL())

      // message.channel.send(embed)

    },
    permissiongs: [],
    requiredRoles: ['Say']
}




