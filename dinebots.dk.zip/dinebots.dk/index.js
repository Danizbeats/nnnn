const Discord = require('discord.js');                                                          
const bot = new Discord.Client();
const cfg = require('./config.json');
const token = "OTY5NTU4NTUxODIxNDI2NzY5.YmvJxA.A5zDeMjsdFIR6aiymuTiFXjW1wA";
const fs = require('fs')

const path = require('path')

bot.on('ready', () => {
    console.log('Welcome to Say bot...\n My name is '+ bot.user.username)
    // setTimeout(check_servers_hosting, 1500)
    // setTimeout(check_servers_marcus, 2900)

    const baseFile = 'command-base.js'
    const commandBase = require(`./commands/${baseFile}`)


    const readCommands = dir => {
        const files = fs.readdirSync(path.join(__dirname, dir))
        for (const file of files){
            const stat = fs.lstatSync(path.join(__dirname, dir, file))
            if(stat.isDirectory()){
                readCommands(path.join(dir, file))
            } else  if (file !== baseFile){
                const option = require(path.join(__dirname,dir,file))
                commandBase(bot, option)
            }
        }
    }

    readCommands('commands')
})


// Create a welcome message when a user joins the server
bot.on('guildMemberAdd', member => {
    const channel = member.guild.channels.cache.find(ch => ch.id === '968213602647572500')
    if (!channel) return
    channel.send(`Velkommen ${member.user.username}, til Salg af Custom Discord Bot's Discord!\n.`)
})


bot.login(token)